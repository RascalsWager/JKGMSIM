# Jester King GM Simulator

Android-ready Kivy project.

## App name

Jester King GM Simulator

## Repo layout

Put these files in the root of your GitHub repo:

```text
main.py
buildozer.spec
README.txt
.github/workflows/main.yml
```

## Build APK on GitHub

1. Commit the files to your repo.
2. Go to Actions.
3. Run Build Android APK.
4. Download the artifact named jester-king-gm-simulator-apk.
5. Inside the artifact ZIP should be the APK.

## Android notes

This build uses:

- Java 17
- Android API 35
- Minimum Android API 24
- NDK API 24
- Kivy
- Buildozer

The APK will install on Android 7.0 or newer.
